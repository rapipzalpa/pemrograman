import 'package:flutter/material.dart';
import 'my_homepage.dart';  // Mengimpor file my_homepage.dart yang benar
import 'product.dart';  // Mengimpor file product.dart yang benar

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomepage(), // Menampilkan MyHomepage
    );
  }
}
