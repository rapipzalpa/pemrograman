import 'package:flutter/material.dart';
import 'product.dart';  // Mengimpor file product.dart yang benar

class MyHomepage extends StatelessWidget {
  const MyHomepage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Product List'),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart),
            onPressed: () {
              // Logika untuk membuka keranjang dapat ditambahkan di sini
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(8),
        children: const [
          ShoppingListItem(
            product: Product(name: 'Chips'),
          ),
          ShoppingListItem(
            product: Product(name: 'Soda'),
          ),
          ShoppingListItem(
            product: Product(name: 'Cookies'),
          ),
          ShoppingListItem(
            product: Product(name: 'Candy'),
          ),
        ],
      ),
    );
  }
}
